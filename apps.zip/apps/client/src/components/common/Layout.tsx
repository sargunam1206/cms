import { useState } from 'react';
import { NavLink, Outlet } from 'react-router-dom';
import {
  Building2,
  CalendarCheck,
  CalendarDays,
  CheckSquare,
  ClipboardList,
  History,
  LayoutDashboard,
  LogOut,
  Menu,
  Settings,
  ShieldCheck,
  Users,
  KeyRound,
  UserCircle,
  Landmark,
  Wallet,
  Banknote,
  Receipt,
  ListPlus,
  UserMinus,
  FolderKanban,
  GanttChart,
  Target,
  Lightbulb,
  CalendarClock,
  FileLock2,
  Radar,
  GraduationCap,
  BookOpenCheck,
  FileBarChart,
  ListChecks,
  Briefcase,
  Bell,
  Timer,
  ClipboardCheck,
  Plane,
} from 'lucide-react';
import { PERMISSIONS as P, type Permission } from '@cms/shared';
import { useGet } from '@/api/hooks';
import { useImage } from '@/features/settings/CompanyTab';
import { useAuth } from '@/lib/auth';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { BackButton } from './BackButton';
import { ChangePasswordDialog } from './ChangePasswordDialog';
import { NotificationBell } from './NotificationBell';

interface NavItem {
  to: string;
  label: string;
  /** Hidden from interns (they get a stipend, not payslips). */
  employeesOnly?: boolean;
  icon: typeof LayoutDashboard;
  perms?: Permission[];
}

const NAV: { section: string; items: NavItem[] }[] = [
  {
    section: 'Me',
    items: [
      { to: '/', label: 'Dashboard', icon: LayoutDashboard },
      { to: '/profile', label: 'My Profile', icon: UserCircle },
      { to: '/my/attendance', label: 'My Attendance', icon: CalendarCheck, perms: [P.ATTENDANCE_SELF] },
      { to: '/notifications', label: 'Notifications', icon: Bell },
      { to: '/my/timesheet', label: 'My Timesheet', icon: Timer, perms: [P.TASKS_SELF] },
      { to: '/my/tasks', label: 'My Tasks', icon: ListChecks, perms: [P.TASKS_SELF] },
      { to: '/my/payslips', label: 'My Payslips', icon: Receipt, employeesOnly: true },
      { to: '/my/leave', label: 'My Leave', icon: Plane, perms: [P.LEAVE_SELF] },
    ],
  },
  {
    section: 'Work',
    items: [
      { to: '/projects', label: 'Projects', icon: FolderKanban, perms: [P.TASKS_SELF, P.PROJECTS_VIEW, P.PROJECTS_MANAGE] },
      { to: '/timesheets/approvals', label: 'Timesheet Approvals', icon: ClipboardCheck, perms: [P.LEAVE_APPROVE, P.ATTENDANCE_ALL] },
      { to: '/estimates/report', label: 'Estimate Report', icon: FileBarChart, perms: [P.ESTIMATES_VIEW] },
      { to: '/intern-work', label: 'Intern Work', icon: BookOpenCheck, perms: [P.INTERN_SELF, P.INTERNS_MENTOR, P.INTERNS_MANAGE] },
      { to: '/tracker', label: 'Project Tracker', icon: Radar, perms: [P.PROJECTS_VIEW] },
      { to: '/timelines', label: 'Timelines', icon: GanttChart, perms: [P.PROJECTS_VIEW] },
      { to: '/meetings', label: 'Meetings', icon: CalendarClock, perms: [P.MEETINGS_SELF, P.MEETINGS_MANAGE] },
      { to: '/ideas', label: 'Innovation Hub', icon: Lightbulb, perms: [P.IDEAS_SELF, P.IDEAS_MANAGE] },
      { to: '/enquiries', label: 'Enquiries', icon: Target, perms: [P.ENQUIRIES_SELF, P.ENQUIRIES_VIEW, P.ENQUIRIES_MANAGE] },
      { to: '/clients', label: 'Clients', icon: Briefcase, perms: [P.PROJECTS_MANAGE, P.PROJECTS_VIEW] },
    ],
  },
  {
    section: 'Team',
    items: [
      { to: '/approvals', label: 'Approvals', icon: CheckSquare, perms: [P.LEAVE_APPROVE, P.REGULARIZATION_APPROVE] },
      { to: '/attendance/register', label: 'Attendance Register', icon: ClipboardList, perms: [P.ATTENDANCE_TEAM, P.ATTENDANCE_ALL] },
      { to: '/leave/admin', label: 'Leave Management', icon: CalendarDays, perms: [P.LEAVE_MANAGE] },
    ],
  },
  {
    section: 'Admin',
    items: [
      { to: '/employees', label: 'Employees', icon: Building2, perms: [P.EMPLOYEES_VIEW] },
      { to: '/interns', label: 'Interns', icon: GraduationCap, perms: [P.INTERNS_MANAGE, P.INTERNS_MENTOR] },
      { to: '/profile-changes', label: 'Bank Changes', icon: Landmark, perms: [P.EMPLOYEES_MANAGE] },
      { to: '/confidential', label: 'Confidential Docs', icon: FileLock2, perms: [P.CONFIDENTIAL_VIEW, P.CONFIDENTIAL_MANAGE] },
      { to: '/payroll/runs', label: 'Payroll Runs', icon: Banknote, perms: [P.PAYROLL_VIEW, P.PAYROLL_MANAGE] },
      { to: '/payroll/adjustments', label: 'Payroll Adjustments', icon: ListPlus, perms: [P.PAYROLL_VIEW, P.PAYROLL_MANAGE] },
      { to: '/payroll/fnf', label: 'Full & Final', icon: UserMinus, perms: [P.PAYROLL_VIEW, P.PAYROLL_MANAGE] },
      { to: '/payroll/setup', label: 'Payroll Setup', icon: Wallet, perms: [P.PAYROLL_VIEW, P.PAYROLL_MANAGE] },
      { to: '/users', label: 'Users & Roles', icon: Users, perms: [P.USERS_MANAGE, P.ROLES_MANAGE] },
      { to: '/settings', label: 'Settings', icon: Settings, perms: [P.SETTINGS_MANAGE, P.HOLIDAYS_MANAGE, P.LEAVE_MANAGE, P.ESTIMATES_VIEW, P.ENQUIRIES_MANAGE] },
      { to: '/audit', label: 'Audit Log', icon: History, perms: [P.AUDIT_VIEW] },
    ],
  },
];

export function Layout() {
  const { user, can, logout } = useAuth();
  const [open, setOpen] = useState(false);
  const [pwOpen, setPwOpen] = useState(false);
  const company = useGet<{ name: string; hasLogo?: boolean }>(['company'], '/company');
  const logo = useImage('logo', !!company.data?.hasLogo, company.dataUpdatedAt);

  const sidebar = (
    <nav className="flex h-full flex-col p-3">
      <div className="shrink-0 px-2 py-2">
        <div className="flex items-center justify-between gap-2">
          {logo ? <img src={logo} alt="" className="max-h-12 max-w-[8.5rem] object-contain object-left" /> : <ShieldCheck className="h-6 w-6 shrink-0 text-primary" />}
          <NotificationBell />
        </div>
        <div className="mt-2 break-words text-sm font-semibold leading-snug">{company.data?.name || 'CMS'}</div>
      </div>
      {/* only the menu scrolls; the company header and the user block stay in place */}
      <div className="-mx-1 mt-2 min-h-0 flex-1 space-y-4 overflow-y-auto px-1 pb-2">
      {NAV.map(({ section, items }) => {
        const intern = user?.employee?.type === 'intern';
        const visible = items.filter((i) => (!i.perms || can(...i.perms)) && !(intern && i.employeesOnly));
        if (!visible.length) return null;
        return (
          <div key={section}>
            <div className="px-2 pb-1 text-xs font-medium uppercase tracking-wide text-muted-foreground">{section}</div>
            {visible.map(({ to, label, icon: Icon }) => (
              <NavLink
                key={to}
                to={to}
                end={to === '/'}
                onClick={() => setOpen(false)}
                className={({ isActive }) =>
                  cn(
                    'flex items-center gap-2 rounded-md px-2 py-1.5 text-sm hover:bg-accent',
                    isActive && 'bg-primary/10 font-medium text-primary',
                  )
                }
              >
                <Icon className="h-4 w-4" /> {label}
              </NavLink>
            ))}
          </div>
        );
      })}
      </div>
      <div className="shrink-0 border-t pt-3">
        <div className="px-2 text-sm font-medium">{user?.employee?.name ?? user?.email}</div>
        <div className="px-2 pb-2 text-xs text-muted-foreground">{user?.role}</div>
        <Button variant="ghost" size="sm" className="w-full justify-start" onClick={() => setPwOpen(true)}>
          <KeyRound /> Change password
        </Button>
        <Button variant="ghost" size="sm" className="w-full justify-start" onClick={logout}>
          <LogOut /> Sign out
        </Button>
      </div>
    </nav>
  );

  return (
    <div className="flex min-h-screen">
      <aside className="sticky top-0 hidden h-screen w-60 shrink-0 border-r bg-background md:block">{sidebar}</aside>
      {open && (
        <div className="fixed inset-0 z-40 md:hidden" onClick={() => setOpen(false)}>
          <div className="absolute inset-0 bg-black/30" />
          <aside className="absolute left-0 top-0 h-full w-64 bg-background" onClick={(e) => e.stopPropagation()}>
            {sidebar}
          </aside>
        </div>
      )}
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex h-12 items-center border-b bg-background px-4 md:hidden">
          <Button variant="ghost" size="icon" onClick={() => setOpen(true)} aria-label="Open menu">
            <Menu />
          </Button>
          <span className="ml-2 font-semibold">{company.data?.name || 'CMS'}</span>
          <div className="ml-auto">
            <NotificationBell />
          </div>
        </header>
        <main className="mx-auto w-full max-w-7xl flex-1 p-4 md:p-8">
          <BackButton />
          <Outlet />
        </main>
      </div>
      <ChangePasswordDialog open={pwOpen} onOpenChange={setPwOpen} />
    </div>
  );
}
