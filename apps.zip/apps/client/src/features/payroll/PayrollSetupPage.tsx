import { useEffect, useState } from 'react';
import { Plus } from 'lucide-react';
import { toast } from 'sonner';
import { PERMISSIONS as P } from '@cms/shared';
import { useGet, useSend } from '@/api/hooks';
import type { Employee, Paged } from '@/api/types';
import { useAuth } from '@/lib/auth';
import { PageHeader, Spinner } from '@/components/common/page';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Checkbox, Field, Input, Select } from '@/components/ui/form-controls';
import { EmptyRow, Table, TBody, TD, TH, THead, TR } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { LinesEditor } from './LinesEditor';
import type { PayComponent, PayLine, PayTemplate, Statutory } from './types';

export function PayrollSetupPage() {
  const { can } = useAuth();
  const canEdit = can(P.PAYROLL_MANAGE);
  return (
    <>
      <PageHeader title="Payroll setup" description="Salary components, templates and statutory rules. Rates are settings, never code." />
      <Tabs defaultValue="components">
        <TabsList>
          <TabsTrigger value="components">Components</TabsTrigger>
          <TabsTrigger value="templates">Templates</TabsTrigger>
          <TabsTrigger value="statutory">Statutory</TabsTrigger>
          <TabsTrigger value="approval">Approval</TabsTrigger>
        </TabsList>
        <TabsContent value="components">
          <ComponentsTab canEdit={canEdit} />
        </TabsContent>
        <TabsContent value="templates">
          <TemplatesTab canEdit={canEdit} />
        </TabsContent>
        <TabsContent value="approval">
          <ApprovalTab canEdit={canEdit} />
        </TabsContent>
        <TabsContent value="statutory">
          <StatutoryTab canEdit={canEdit} />
        </TabsContent>
      </Tabs>
    </>
  );
}

// ---------- Approval chain ----------
function ApprovalTab({ canEdit }: { canEdit: boolean }) {
  const { data } = useGet<{ managementApproval: boolean }>(['payroll', 'workflow'], '/payroll/workflow');
  const save = useSend<boolean>('put', '/payroll/workflow', { invalidate: [['payroll']], success: 'Saved', body: (v) => ({ managementApproval: v }) });
  return (
    <Card>
      <CardContent className="space-y-2 pt-5 text-sm">
        <label className="flex items-center gap-2 font-medium">
          <Checkbox checked={data?.managementApproval ?? true} disabled={!canEdit || save.isPending} onChange={(e) => save.mutate(e.target.checked)} />
          Require Management approval after HR review
        </label>
        <p className="text-muted-foreground">
          On: HR submits the run and a Management user (a different person) approves it. Off: HR's submission is the final approval. The approval is what locks the run, reduces loan balances and releases payslips to employees.
        </p>
      </CardContent>
    </Card>
  );
}

function DeleteButton({ url, confirm }: { url: string; confirm: string }) {
  const del = useSend('delete', url, { invalidate: [['payroll']], success: 'Deleted' });
  return (
    <Button size="sm" variant="ghost" className="text-destructive" disabled={del.isPending} onClick={() => window.confirm(confirm) && del.mutate(undefined)}>
      Delete
    </Button>
  );
}

// ---------- Components ----------
const blankComponent: Omit<PayComponent, '_id'> = { code: '', name: '', kind: 'earning', taxable: true, prorate: true, order: 10, active: true };

function ComponentsTab({ canEdit }: { canEdit: boolean }) {
  const { data } = useGet<PayComponent[]>(['payroll', 'components'], '/payroll/components');
  const [editing, setEditing] = useState<PayComponent | 'new' | null>(null);
  return (
    <>
      {canEdit && (
        <div className="mb-3 flex justify-end">
          <Button onClick={() => setEditing('new')}>
            <Plus /> New component
          </Button>
        </div>
      )}
      <Card>
        <CardContent className="p-0">
          <Table>
            <THead>
              <TR>
                <TH>Order</TH>
                <TH>Code</TH>
                <TH>Name</TH>
                <TH>Type</TH>
                <TH>Taxable</TH>
                <TH>Prorated</TH>
                <TH>Status</TH>
                <TH />
              </TR>
            </THead>
            <TBody>
              {!data?.length && <EmptyRow cols={8} text="No components yet. Add BASIC, HRA and so on." />}
              {data?.map((c) => (
                <TR key={c._id}>
                  <TD>{c.order}</TD>
                  <TD className="font-mono text-xs">{c.code}</TD>
                  <TD>{c.name}</TD>
                  <TD>{c.kind}</TD>
                  <TD>{c.kind === 'earning' ? (c.taxable ? 'Yes' : 'No') : '—'}</TD>
                  <TD>{c.kind === 'earning' ? (c.prorate ? 'Yes' : 'No') : '—'}</TD>
                  <TD>{c.active ? <Badge variant="success">active</Badge> : <Badge variant="secondary">inactive</Badge>}</TD>
                  <TD className="text-right">
                    {canEdit && (
                      <>
                        <Button size="sm" variant="ghost" onClick={() => setEditing(c)}>
                          Edit
                        </Button>
                        <DeleteButton url={`/payroll/components/${c._id}`} confirm={`Delete component ${c.code}?`} />
                      </>
                    )}
                  </TD>
                </TR>
              ))}
            </TBody>
          </Table>
        </CardContent>
      </Card>
      <ComponentDialog editing={editing} onClose={() => setEditing(null)} />
    </>
  );
}

function ComponentDialog({ editing, onClose }: { editing: PayComponent | 'new' | null; onClose: () => void }) {
  const isNew = editing === 'new';
  const existing = typeof editing === 'object' && editing ? editing : null;
  const [f, setF] = useState<Omit<PayComponent, '_id'>>(blankComponent);
  useEffect(() => {
    if (editing === 'new') setF(blankComponent);
    else if (editing) setF({ code: editing.code, name: editing.name, kind: editing.kind, taxable: editing.taxable, prorate: editing.prorate, order: editing.order, active: editing.active });
  }, [editing]);
  const save = useSend(isNew ? 'post' : 'put', isNew ? '/payroll/components' : `/payroll/components/${existing?._id ?? ''}`, {
    invalidate: [['payroll']],
    success: 'Saved',
    onSuccess: onClose,
    // the server needs a value to validate against the shared schema; values belong to templates, so send a placeholder
    body: () => ({ ...f, fixedAmount: 0 }),
  });
  return (
    <Dialog open={!!editing} onOpenChange={(o) => !o && onClose()}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{isNew ? 'New component' : `Edit ${f.code}`}</DialogTitle>
        </DialogHeader>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Code (capitals, e.g. HRA)">
            <Input value={f.code} disabled={!isNew} onChange={(e) => setF({ ...f, code: e.target.value.toUpperCase() })} />
          </Field>
          <Field label="Name">
            <Input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
          </Field>
          <Field label="Type">
            <Select value={f.kind} onChange={(e) => setF({ ...f, kind: e.target.value as 'earning' | 'deduction' })}>
              <option value="earning">Earning</option>
              <option value="deduction">Deduction</option>
            </Select>
          </Field>
          <Field label="Order on payslip">
            <Input type="number" min={0} value={f.order} onChange={(e) => setF({ ...f, order: Number(e.target.value) })} />
          </Field>
          {f.kind === 'earning' && (
            <>
              <label className="flex items-center gap-2 text-sm">
                <Checkbox checked={f.taxable} onChange={(e) => setF({ ...f, taxable: e.target.checked })} /> Taxable
              </label>
              <label className="flex items-center gap-2 text-sm">
                <Checkbox checked={f.prorate} onChange={(e) => setF({ ...f, prorate: e.target.checked })} /> Reduce for loss-of-pay days
              </label>
            </>
          )}
          <label className="flex items-center gap-2 text-sm">
            <Checkbox checked={f.active} onChange={(e) => setF({ ...f, active: e.target.checked })} /> Active
          </label>
        </div>
        <DialogFooter>
          <Button disabled={save.isPending || !f.code || !f.name} onClick={() => save.mutate(undefined)}>
            Save
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ---------- Templates ----------
function TemplatesTab({ canEdit }: { canEdit: boolean }) {
  const { data } = useGet<PayTemplate[]>(['payroll', 'templates'], '/payroll/templates');
  const [editing, setEditing] = useState<PayTemplate | 'new' | null>(null);
  const [applying, setApplying] = useState<PayTemplate | null>(null);
  const [assigning, setAssigning] = useState<PayTemplate | null>(null);
  return (
    <>
      {canEdit && (
        <div className="mb-3 flex justify-end">
          <Button onClick={() => setEditing('new')}>
            <Plus /> New template
          </Button>
        </div>
      )}
      <Card>
        <CardContent className="p-0">
          <Table>
            <THead>
              <TR>
                <TH>Name</TH>
                <TH>Components</TH>
                <TH />
              </TR>
            </THead>
            <TBody>
              {!data?.length && <EmptyRow cols={3} text="No templates yet. A template is a ready-made salary layout you can start an employee from." />}
              {data?.map((t) => (
                <TR key={t._id}>
                  <TD className="font-medium">{t.name}</TD>
                  <TD className="text-xs text-muted-foreground">{t.lines.map((l) => l.code).join(', ')}</TD>
                  <TD className="text-right">
                    {canEdit && (
                      <>
                        <Button size="sm" variant="ghost" onClick={() => setEditing(t)}>
                          Edit
                        </Button>
                        <DeleteButton url={`/payroll/templates/${t._id}`} confirm={`Delete template "${t.name}"? Employees already set up from it keep their own salary lines.`} />
                        <Button size="sm" variant="ghost" onClick={() => setAssigning(t)}>
                          Assign to employees
                        </Button>
                        <Button size="sm" variant="ghost" onClick={() => setApplying(t)}>
                          Update current users
                        </Button>
                      </>
                    )}
                  </TD>
                </TR>
              ))}
            </TBody>
          </Table>
        </CardContent>
      </Card>
      <p className="mt-2 text-xs text-muted-foreground">
        Saving a template does not change employees already set up from it; each employee keeps their own copy. Use "Apply to employees" to copy the template onto everyone whose current salary was started from it.
      </p>
      <TemplateDialog editing={editing} onClose={() => setEditing(null)} />
      <ApplyDialog template={applying} onClose={() => setApplying(null)} />
      <AssignDialog template={assigning} onClose={() => setAssigning(null)} />
    </>
  );
}

function AssignDialog({ template, onClose }: { template: PayTemplate | null; onClose: () => void }) {
  const [from, setFrom] = useState('');
  const [q, setQ] = useState('');
  const [picked, setPicked] = useState<Set<string>>(new Set());
  const emps = useGet<Paged<Employee>>(['employees', 'all', 'employee'], '/employees', { limit: 500, status: 'active', type: 'employee' }, !!template);
  useEffect(() => {
    if (template) {
      setFrom(new Date().toISOString().slice(0, 8) + '01');
      setQ('');
      setPicked(new Set());
    }
  }, [template]);
  const list = (emps.data?.items ?? []).filter((e) => `${e.name} ${e.code} ${e.department ?? ''}`.toLowerCase().includes(q.toLowerCase()));
  const toggle = (id: string) =>
    setPicked((s) => {
      const n = new Set(s);
      if (n.has(id)) n.delete(id);
      else n.add(id);
      return n;
    });
  const allShown = list.length > 0 && list.every((e) => picked.has(e._id));
  const assign = useSend<void, { updated: number }>('post', `/payroll/templates/${template?._id ?? ''}/assign`, {
    invalidate: [['payroll']],
    onSuccess: (r) => {
      toast.success(`Template assigned to ${r.updated} employee${r.updated === 1 ? '' : 's'}`);
      onClose();
    },
    body: () => ({ employeeIds: [...picked], effectiveFrom: from }),
  });
  return (
    <Dialog open={!!template} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>Assign "{template?.name}" to employees</DialogTitle>
        </DialogHeader>
        <p className="text-sm text-muted-foreground">Each chosen employee gets their own copy of this template's salary lines from the date below, replacing any salary set for that exact date.</p>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Effective from">
            <Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
          </Field>
          <Field label="Search">
            <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Name, code or department" />
          </Field>
        </div>
        <label className="flex items-center gap-2 text-sm">
          <Checkbox
            checked={allShown}
            onChange={() =>
              setPicked((s) => {
                const n = new Set(s);
                list.forEach((e) => (allShown ? n.delete(e._id) : n.add(e._id)));
                return n;
              })
            }
          />
          Select all shown ({list.length})
        </label>
        <div className="max-h-64 space-y-1 overflow-y-auto rounded-md border p-2">
          {emps.isLoading && <Spinner />}
          {list.map((e) => (
            <label key={e._id} className="flex items-center gap-2 text-sm">
              <Checkbox checked={picked.has(e._id)} onChange={() => toggle(e._id)} />
              <span className="font-medium">{e.name}</span>
              <span className="text-xs text-muted-foreground">
                {e.code}
                {e.department ? ` · ${e.department}` : ''}
              </span>
            </label>
          ))}
          {!emps.isLoading && !list.length && <p className="text-sm text-muted-foreground">No employees match.</p>}
        </div>
        <DialogFooter>
          <Button disabled={assign.isPending || !from || !picked.size} onClick={() => assign.mutate(undefined)}>
            Assign to {picked.size || ''} selected
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function ApplyDialog({ template, onClose }: { template: PayTemplate | null; onClose: () => void }) {
  const [from, setFrom] = useState('');
  useEffect(() => {
    if (template) setFrom(new Date().toISOString().slice(0, 8) + '01');
  }, [template]);
  const apply = useSend<void, { updated: number }>('post', `/payroll/templates/${template?._id ?? ''}/apply`, {
    invalidate: [['payroll']],
    onSuccess: (r) => {
      toast.success(`Applied to ${r.updated} employee${r.updated === 1 ? '' : 's'}`);
      onClose();
    },
    body: () => ({ effectiveFrom: from }),
  });
  return (
    <Dialog open={!!template} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Apply "{template?.name}" to employees</DialogTitle>
        </DialogHeader>
        <p className="text-sm text-muted-foreground">
          Replaces the salary lines of every employee whose current salary was started from this template, from the date below. Their own edits to those lines are overwritten. Earlier months are not touched; to update a payslip already computed, recompute that run.
        </p>
        <Field label="Effective from">
          <Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
        </Field>
        <DialogFooter>
          <Button disabled={apply.isPending || !from} onClick={() => apply.mutate(undefined)}>
            Apply
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function TemplateDialog({ editing, onClose }: { editing: PayTemplate | 'new' | null; onClose: () => void }) {
  const isNew = editing === 'new';
  const existing = typeof editing === 'object' && editing ? editing : null;
  const comps = useGet<PayComponent[]>(['payroll', 'components'], '/payroll/components', undefined, !!editing);
  const [name, setName] = useState('');
  const [lines, setLines] = useState<PayLine[]>([]);
  useEffect(() => {
    if (editing === 'new') {
      setName('');
      setLines([]);
    } else if (editing) {
      setName(editing.name);
      setLines(editing.lines);
    }
  }, [editing]);
  const save = useSend(isNew ? 'post' : 'put', isNew ? '/payroll/templates' : `/payroll/templates/${existing?._id ?? ''}`, {
    invalidate: [['payroll']],
    success: 'Saved',
    onSuccess: onClose,
    body: () => ({ name, lines }),
  });
  return (
    <Dialog open={!!editing} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>{isNew ? 'New salary template' : 'Edit template'}</DialogTitle>
        </DialogHeader>
        <Field label="Template name">
          <Input value={name} onChange={(e) => setName(e.target.value)} />
        </Field>
        <LinesEditor lines={lines} components={comps.data ?? []} onChange={setLines} />
        <DialogFooter>
          <Button disabled={save.isPending || name.trim().length < 2 || !lines.length} onClick={() => save.mutate(undefined)}>
            Save
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ---------- Statutory ----------
const pct = (v: number) => Math.round(v * 10000) / 100; // 0.0075 -> 0.75
const frac = (v: string) => Number(v) / 100;

function Num({ label, value, onChange, suffix, step }: { label: string; value: number; onChange: (v: number) => void; suffix?: string; step?: string }) {
  return (
    <Field label={`${label}${suffix ? ` (${suffix})` : ''}`}>
      <Input type="number" step={step ?? 'any'} value={Number.isFinite(value) ? value : 0} onChange={(e) => onChange(Number(e.target.value))} />
    </Field>
  );
}

function StatutoryTab({ canEdit }: { canEdit: boolean }) {
  const { data, isLoading } = useGet<Statutory>(['payroll', 'statutory'], '/payroll/statutory');
  const [s, setS] = useState<Statutory | null>(null);
  const [from, setFrom] = useState('');
  useEffect(() => {
    if (data) setS(structuredClone(data));
  }, [data]);
  const save = useSend('put', '/payroll/statutory', {
    invalidate: [['payroll']],
    success: 'Statutory rules saved',
    body: () => ({ value: s, effectiveFrom: from || undefined }),
  });
  if (isLoading || !s) return <Spinner />;
  const up = (fn: (d: Statutory) => void) => {
    const n = structuredClone(s);
    fn(n);
    setS(n);
  };

  return (
    <div className="space-y-4">
      <p className="rounded-md border border-amber-300 bg-amber-50 p-3 text-sm text-amber-900">
        These are placeholder values. Have your CA verify every rate, ceiling and slab before running real payroll.
      </p>

      <Card>
        <CardHeader className="flex-row items-center justify-between space-y-0">
          <CardTitle className="text-base">Provident Fund (PF)</CardTitle>
          <label className="flex items-center gap-2 text-sm">
            <Checkbox checked={s.pf.enabled} onChange={(e) => up((d) => void (d.pf.enabled = e.target.checked))} /> Enabled
          </label>
        </CardHeader>
        <CardContent className="grid gap-3 sm:grid-cols-4">
          <Num label="Employee rate" suffix="%" value={pct(s.pf.employeeRate)} onChange={(v) => up((d) => void (d.pf.employeeRate = frac(String(v))))} />
          <Num label="Employer rate" suffix="%" value={pct(s.pf.employerRate)} onChange={(v) => up((d) => void (d.pf.employerRate = frac(String(v))))} />
          <Num label="Wage ceiling" suffix="₹/month" value={s.pf.wageCeiling} onChange={(v) => up((d) => void (d.pf.wageCeiling = v))} />
          <Field label="PF wages = these components">
            <Input value={s.pf.basisComponents.join(',')} onChange={(e) => up((d) => void (d.pf.basisComponents = e.target.value.toUpperCase().split(',').map((x) => x.trim()).filter(Boolean)))} />
          </Field>
          <label className="flex items-center gap-2 text-sm sm:col-span-4">
            <Checkbox checked={s.pf.capAtCeiling} onChange={(e) => up((d) => void (d.pf.capAtCeiling = e.target.checked))} /> Limit contribution to the wage ceiling
          </label>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex-row items-center justify-between space-y-0">
          <CardTitle className="text-base">ESI</CardTitle>
          <label className="flex items-center gap-2 text-sm">
            <Checkbox checked={s.esi.enabled} onChange={(e) => up((d) => void (d.esi.enabled = e.target.checked))} /> Enabled
          </label>
        </CardHeader>
        <CardContent className="grid gap-3 sm:grid-cols-3">
          <Num label="Employee rate" suffix="%" value={pct(s.esi.employeeRate)} onChange={(v) => up((d) => void (d.esi.employeeRate = frac(String(v))))} />
          <Num label="Employer rate" suffix="%" value={pct(s.esi.employerRate)} onChange={(v) => up((d) => void (d.esi.employerRate = frac(String(v))))} />
          <Num label="Applies up to gross" suffix="₹/month" value={s.esi.grossThreshold} onChange={(v) => up((d) => void (d.esi.grossThreshold = v))} />
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex-row items-center justify-between space-y-0">
          <CardTitle className="text-base">Professional Tax (Tamil Nadu, half-yearly)</CardTitle>
          <label className="flex items-center gap-2 text-sm">
            <Checkbox checked={s.pt.enabled} onChange={(e) => up((d) => void (d.pt.enabled = e.target.checked))} /> Enabled
          </label>
        </CardHeader>
        <CardContent className="space-y-3">
          <Field label="Collected in months (numbers, e.g. 9,3)">
            <Input
              className="w-48"
              value={s.pt.deductionMonths.join(',')}
              onChange={(e) => up((d) => void (d.pt.deductionMonths = e.target.value.split(',').map((x) => Number(x.trim())).filter((n) => n >= 1 && n <= 12)))}
            />
          </Field>
          <SlabTable
            head={['Half-yearly gross up to (₹)', 'Tax (₹)']}
            rows={s.pt.slabs.map((x) => [x.upTo, x.amount])}
            onChange={(rows) => up((d) => void (d.pt.slabs = rows.map(([upTo, amount]) => ({ upTo, amount: amount ?? 0 }))))}
          />
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex-row items-center justify-between space-y-0">
          <CardTitle className="text-base">Income tax (TDS on salary)</CardTitle>
          <label className="flex items-center gap-2 text-sm">
            <Checkbox checked={s.tds.enabled} onChange={(e) => up((d) => void (d.tds.enabled = e.target.checked))} /> Enabled
          </label>
        </CardHeader>
        <CardContent className="space-y-4">
          <Num label="Health & education cess" suffix="%" value={pct(s.tds.cessRate)} onChange={(v) => up((d) => void (d.tds.cessRate = frac(String(v))))} />
          {(['newRegime', 'oldRegime'] as const).map((k) => (
            <div key={k} className="rounded-md border p-3">
              <h4 className="mb-2 text-sm font-semibold">{k === 'newRegime' ? 'New regime' : 'Old regime (without deductions)'}</h4>
              <div className="mb-3 grid gap-3 sm:grid-cols-3">
                <Num label="Standard deduction" suffix="₹" value={s.tds[k].standardDeduction} onChange={(v) => up((d) => void (d.tds[k].standardDeduction = v))} />
                <Num label="Rebate if income up to" suffix="₹" value={s.tds[k].rebateLimit} onChange={(v) => up((d) => void (d.tds[k].rebateLimit = v))} />
                <Num label="Maximum rebate" suffix="₹" value={s.tds[k].rebateMax} onChange={(v) => up((d) => void (d.tds[k].rebateMax = v))} />
              </div>
              <SlabTable
                head={['Income up to (₹)', 'Rate (%)']}
                rows={s.tds[k].slabs.map((x) => [x.upTo, pct(x.rate)])}
                onChange={(rows) => up((d) => void (d.tds[k].slabs = rows.map(([upTo, rate]) => ({ upTo, rate: (rate ?? 0) / 100 }))))}
              />
            </div>
          ))}
        </CardContent>
      </Card>

      {canEdit && (
        <div className="flex flex-wrap items-end gap-3">
          <Field label="Effective from (blank = today)">
            <Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
          </Field>
          <Button disabled={save.isPending} onClick={() => save.mutate(undefined)}>
            Save statutory rules
          </Button>
        </div>
      )}
    </div>
  );
}

/** Two-column slab editor; an empty first column means "no upper limit" (last row). */
function SlabTable({ head, rows, onChange }: { head: [string, string]; rows: (number | null)[][]; onChange: (r: [number | null, number][]) => void }) {
  const norm = rows.map((r) => [r[0], r[1] ?? 0] as [number | null, number]);
  const set = (i: number, j: 0 | 1, raw: string) => {
    const next = norm.map((r) => [...r] as [number | null, number]);
    if (j === 0) next[i][0] = raw === '' ? null : Number(raw);
    else next[i][1] = Number(raw);
    onChange(next);
  };
  return (
    <div className="space-y-1">
      <div className="grid grid-cols-[1fr_1fr_auto] gap-2 text-xs text-muted-foreground">
        <span>{head[0]}</span>
        <span>{head[1]}</span>
        <span />
      </div>
      {norm.map((r, i) => (
        <div key={i} className="grid grid-cols-[1fr_1fr_auto] gap-2">
          <Input type="number" placeholder="no limit" value={r[0] ?? ''} onChange={(e) => set(i, 0, e.target.value)} />
          <Input type="number" step="any" value={r[1]} onChange={(e) => set(i, 1, e.target.value)} />
          <Button type="button" size="sm" variant="ghost" onClick={() => onChange(norm.filter((_, j) => j !== i))}>
            Remove
          </Button>
        </div>
      ))}
      <Button type="button" size="sm" variant="outline" onClick={() => onChange([...norm, [null, 0]])}>
        Add slab
      </Button>
    </div>
  );
}
