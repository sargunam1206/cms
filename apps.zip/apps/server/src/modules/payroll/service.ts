import {
  DEFAULT_STATUTORY,
  statutorySchema,
  type StatutorySettings,
} from "@cms/shared";
import { badRequest } from "../../utils/errors";
import { lastDayOfMonth } from "../../utils/time";
import { attendanceSummary } from "../attendance/service";
import { Employee } from "../employees/model";
import { getSetting } from "../settings/service";
import { FormulaError } from "./formula";
import {
  computePayroll,
  PayrollError,
  resolveOrder,
  type EngineComponent,
  type EngineResult,
} from "./engine";
import { SalaryComponent, SalaryStructure } from "./model";

export const STATUTORY_KEY = "statutory";

/** Statutory rules in force on a date; stored values are merged over defaults so older records keep working. */
export async function getStatutory(asOf?: string): Promise<StatutorySettings> {
  const stored = await getSetting<Partial<StatutorySettings>>(
    STATUTORY_KEY,
    asOf,
  );
  return statutorySchema.parse({ ...DEFAULT_STATUTORY, ...(stored ?? {}) });
}

interface Line {
  code: string;
  fixedAmount?: number | null;
  formula?: string | null;
}

/** Joins an already-loaded component master with structure lines into engine components. */
export function engineComponentsFrom(
  master: { code: string; name: string; kind: 'earning' | 'deduction'; taxable: boolean; prorate: boolean; order: number }[],
  lines: Line[],
): EngineComponent[] {
  const byCode = new Map(master.map((m) => [m.code, m]));
  return lines.map((l) => {
    const m = byCode.get(l.code);
    if (!m)
      throw badRequest(`Unknown or inactive salary component "${l.code}"`);
    return {
      code: m.code,
      name: m.name,
      kind: m.kind,
      taxable: m.taxable,
      prorate: m.prorate,
      order: m.order,
      ...(l.formula
        ? { formula: l.formula }
        : { fixedAmount: l.fixedAmount ?? 0 }),
    };
  });
}

/** Joins the component master with an employee's structure lines into engine components. */
export async function buildEngineComponents(
  lines: Line[],
): Promise<EngineComponent[]> {
  const master = await SalaryComponent.find({
    code: { $in: lines.map((l) => l.code) },
    active: true,
  }).lean();
  return engineComponentsFrom(master, lines);
}

/** Checks a set of lines can be evaluated (known codes, no cycles, safe formulas) before they are saved. */
export async function validateLines(lines: Line[]) {
  if (new Set(lines.map((l) => l.code)).size !== lines.length)
    throw badRequest("A component appears twice");
  try {
    resolveOrder(await buildEngineComponents(lines));
  } catch (e) {
    if (e instanceof PayrollError || e instanceof FormulaError)
      throw badRequest(e.message);
    throw e;
  }
}

/** The structure in force for a month, or null when the employee has none yet. */
export async function structureFor(employeeId: string, month: string) {
  return SalaryStructure.findOne({
    employee: employeeId,
    effectiveFrom: { $lte: lastDayOfMonth(month) },
  })
    .sort({ effectiveFrom: -1 })
    .lean();
}

/** Computes one employee's pay for a month from live data. Nothing is saved. */
export async function previewPayslip(
  employeeId: string,
  month: string,
): Promise<EngineResult & { employee: { name: string; code: string } }> {
  const emp = await Employee.findById(employeeId).lean();
  if (!emp) throw badRequest("Employee not found");
  const structure = await structureFor(employeeId, month);
  if (!structure)
    throw badRequest(
      `${emp.name} has no salary structure effective for ${month}`,
    );
  const [summary, statutory, components] = await Promise.all([
    attendanceSummary(employeeId, month),
    getStatutory(lastDayOfMonth(month)),
    buildEngineComponents(structure.lines),
  ]);
  let result: EngineResult;
  try {
    result = computePayroll({
      month,
      components,
      attendance: { totalDays: summary.totalDays, paidDays: summary.paidDays },
      employee: {
        pfApplicable: emp.pfApplicable,
        esiApplicable: emp.esiApplicable,
        taxRegime: emp.taxRegime,
      },
      statutory,
    });
  } catch (e) {
    if (e instanceof PayrollError || e instanceof FormulaError)
      throw badRequest(e.message);
    throw e;
  }
  if (summary.pendingDays > 0)
    result.warnings.push(
      `${summary.pendingDays} working day(s) of attendance are still pending`,
    );
  return { ...result, employee: { name: emp.name, code: emp.code } };
}

export interface LayoutRow {
  code: string;
  name: string;
}

/**
 * The rows every payslip shows, in order, even when the amount is zero (printed blank).
 * Earnings and custom deductions come from the component master; PF, ESI, PT and TDS are always listed.
 */
export async function payslipLayout(): Promise<{ earnings: LayoutRow[]; deductions: LayoutRow[] }> {
  const comps = await SalaryComponent.find({ active: true }).sort({ order: 1, code: 1 }).lean();
  const pick = (kind: string) => comps.filter((c) => c.kind === kind).map((c) => ({ code: c.code, name: c.name }));
  return {
    earnings: pick('earning'),
    deductions: [
      ...pick('deduction'),
      { code: 'PF', name: 'Provident Fund' },
      { code: 'ESI', name: 'ESI' },
      { code: 'PT', name: 'Professional Tax' },
      { code: 'TDS', name: 'Income Tax (TDS)' },
    ],
  };
}

/** Layout rows first (amount 0 when absent), then any other lines such as one-time items or loan EMIs. */
export function fillRows<T extends { code?: string | null; name?: string | null; amount?: number | null }>(lines: T[], layout: LayoutRow[]) {
  const rows = layout.map((l) => ({ code: l.code, name: l.name, amount: lines.find((x) => x.code === l.code)?.amount ?? 0 }));
  const known = new Set(layout.map((l) => l.code));
  return [...rows, ...lines.filter((x) => !known.has(x.code ?? '')).map((x) => ({ code: x.code ?? '', name: x.name ?? '', amount: x.amount ?? 0 }))];
}

interface PresentLine {
  code?: string | null;
  name?: string | null;
  amount?: number | null;
  fullAmount?: number | null;
}

const daysLabel = (d: number) => `${Number.isInteger(d) ? d : d.toFixed(1)} ${d === 1 ? 'day' : 'days'}`;

/**
 * How a payslip is shown: earnings at their full value and, when there was loss of pay, a deduction
 * "LOP (2 days)" for the difference. Net pay is unchanged. Stored figures stay as earned, so PF, ESI,
 * PT and TDS (calculated on pay after LOP) and their reports are unaffected.
 * Payslips calculated before full amounts were recorded are shown as they were stored.
 */
export function presentPayslip<S extends { earnings: PresentLine[]; deductions: PresentLine[]; gross?: number | null; totalDeductions?: number | null; attendance?: { lopDays?: number | null } | null }>(slip: S) {
  const lop = slip.earnings.reduce((sum, l) => sum + Math.max(0, (l.fullAmount ?? l.amount ?? 0) - (l.amount ?? 0)), 0);
  const earnings = slip.earnings.map((l) => ({ ...l, amount: l.fullAmount ?? l.amount ?? 0 }));
  if (lop <= 0) return { earnings, deductions: slip.deductions, gross: slip.gross ?? 0, totalDeductions: slip.totalDeductions ?? 0, lopAmount: 0 };
  const days = slip.attendance?.lopDays ?? 0;
  return {
    earnings,
    deductions: [...slip.deductions, { code: 'LOP', name: `LOP (${daysLabel(days)})`, amount: lop }],
    gross: (slip.gross ?? 0) + lop,
    totalDeductions: (slip.totalDeductions ?? 0) + lop,
    lopAmount: lop,
  };
}
